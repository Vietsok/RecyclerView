package com.phs.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class ListView2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view2);

        ListView lvStagiaires2 = findViewById(R.id.lvStagiaires2);

        String[] values = getResources().getStringArray(R.array.stagiaires);

        ListView2Adapter adapter = new ListView2Adapter(this, values);

        lvStagiaires2.setAdapter(adapter);
    }


}