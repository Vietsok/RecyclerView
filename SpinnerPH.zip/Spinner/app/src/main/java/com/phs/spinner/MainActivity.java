package com.phs.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ControleSpinner();
        spinnerJave();
    }

    Spinner spinnerXmlJava;

    //Méthode 2 XML + Java
    private void ControleSpinner() {
        spinnerXmlJava = findViewById(R.id.spinnerXmlJava);
        String[] listValues;
        listValues = getResources().getStringArray(R.array.list);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                // context  design  données
                this, android.R.layout.simple_list_item_1, listValues
        );

        spinnerXmlJava.setAdapter(adapter);
        spinnerXmlJava.setOnItemSelectedListener(this);
    }

    // Méthode 3 Java seul
    String[] spinnerList = {
            "Spinner Java seul",
            "Item 1",
            "Item 2",
            "Item 3"
    };

    private void spinnerJave() {
        Spinner spinnerJava = findViewById(R.id.spinnerJava);
        ArrayAdapter<String> listJava = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, spinnerList
        );

        spinnerJava.setAdapter(listJava);
        spinnerJava.setOnItemSelectedListener(this);

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long l) {
        final Toast myToast = Toast.makeText(getApplicationContext(), "", Toast.LENGTH_LONG);

        switch (parent.getId()) {
            case R.id.spinnerXmlJava:
                myToast.setText("Xml et Java " + spinnerList[pos]);
                myToast.show();
                Log.i(TAG, "Xml et Java " + spinnerList[pos]);
                break;
            case R.id.spinnerJava:
                myToast.setText("Spinner Java " + spinnerList[pos]);
                myToast.show();
                Log.i(TAG, "Spinner Java " + spinnerList[pos]);
                break;
            default:
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        final Toast myToast = Toast.makeText(getApplicationContext(), "", Toast.LENGTH_LONG);
        myToast.setText("Rien");
        myToast.cancel();
    }
}