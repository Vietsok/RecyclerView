package com.phs.spinner;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class ListView2Adapter extends ArrayAdapter<String> {

    private Integer[] avatars = {
            R.drawable.stagiaire_01,
            R.drawable.stagiaire_02,
            R.drawable.stagiaire_03,
            R.drawable.stagiaire_04,
            R.drawable.stagiaire_05,
            R.drawable.stagiaire_06,
            R.drawable.stagiaire_07,
            R.drawable.stagiaire_08,
            R.drawable.stagiaire_09,
            R.drawable.stagiaire_010,
            R.drawable.stagiaire_011,
            R.drawable.stagiaire_012,
            R.drawable.stagiaire_013
    };

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.row_layout, parent, false);

        ImageView ivAvatar = (ImageView) rowView.findViewById(R.id.ivAvatar);
        TextView tvName = (TextView) rowView.findViewById(R.id.tvName);

        tvName.setText(getItem(position));

        if (convertView == null) {
            ivAvatar.setImageResource(avatars[position]);
        } else {
            rowView = (View) convertView;
        }
        return rowView;
    }

    public ListView2Adapter(@NonNull Context context, String[] values) {
        super(context,R.layout.row_layout, values);
    }
}
